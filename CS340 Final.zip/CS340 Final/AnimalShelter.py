#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Sep 24 00:36:09 2023

@author: jonathanway_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId
from pprint import pprint

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31751
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Create method in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

# Read method in CRUD.
    def read(self, search):
        if search is not None:
            #set data to list if found
            data = list(self.database.animals.find(search))
        else:
            #create empty list if not found
            data = list(self.database.animals.find( {}, {"_id": False}))
            raise Exception("Nothing to save, because data parameter is empty")
        return data
    
# Update method in CRUD.
    def update(self, search, updateItem):
        if search is not None:
            result = self.database.animals.update_one(search, { "$set": updateItem})
            return result.raw_result
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return "{}"
        
    
# Delete method in CRUD
    def delete(self, deleteItem):
        if deleteItem is not None:
            result = self.database.animals.delete_one(deleteItem)
        else:
            return "{}"
        return result.raw_result